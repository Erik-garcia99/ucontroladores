#include <avr/io.h>

void delay(void)
{
    volatile uint16_t counter = 0xFFFF;
    while(--counter)
    ;
}

// Implementar un programa que lea el potenciómetro y controle directamente 
// el brillo de ambos LEDs

int main(void)
{
    //Inicializar perifericos
    
    while(1)
    {
        // Leer potenciometro y actualizar brillo del LED
        delay();
    }
}
