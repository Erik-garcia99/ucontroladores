#include<avr/io.h>


int main(void){


	DDRA=0xFF; // todo el puerto A es de salida.  PA0 - PA7 
	
	// PORTA = 0X7F;

  PORTA = 3; 


}